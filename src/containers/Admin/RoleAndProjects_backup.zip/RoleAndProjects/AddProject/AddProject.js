import React from 'react';
import MuiContainer from '@material-ui/core/Container'
import Form from 'react-bootstrap/form'
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Select from '@material-ui/core/Select';
import { getAllRolesForAdmin, addProjects, editProjects } from '../../../../api/admin';
import './AddProject.css'



class AddProject extends React.Component {

    constructor(props){
        super(props)
        this.state = this.getInitialState(); 
    }

    getInitialState = () => {
        const initialState = {
            listRoleNames: [],
            roleNames: [],
            projectName: '',
            projectDetails: this.props.projectDetails
        }
        return initialState;
    }

    componentDidMount () {
        getAllRolesForAdmin(this.postRoleDetails)
    }
    
    postRoleDetails = (response) => {
        this.setState({
            ...this.state,
            listRoleNames: response.data
        })
        
    }

    handleChangeMultiple = (event) => {
        let roleData = this.state.roleNames
        let index = ''
            if ((index = roleData.indexOf(event.target.value)) > -1) {
                roleData.splice(index, 1);
            } else {
                roleData.push(event.target.value);
            }
        this.setState({
            ...this.state,
            roleNames: roleData
        })
    }

    handleChange = (event) => {
        if(this.state.projectDetails) {
            let data = {
                id: this.state.projectDetails.id,
                name: event.target.value
            }
    
            this.setState({
                projectDetails: data
            })
        } else {
            this.setState({
                ...this.state,
                projectName: event.target.value
            })
        }
        

    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.props.isEdit ?
            editProjects(this.postProject, this.state.projectDetails)
            :   
            addProjects(this.postProject, {
                name: this.state.projectName
            })     
    }

    postProject = (response) => {
        this.props.closeModal(false);
    }

    render() {
        const addRole = (
            this.props.isEdit ?
            <Col xs lg="8">
                <Form.Label>Role</Form.Label>
                    <Select
                        multiple
                        native
                        value={this.state.roleNames}
                        onChange={this.handleChangeMultiple}
                        inputProps={{
                            id: 'select-multiple-native',
                        }}
                        className = 'Select-Roles'
                    >
                    {this.state.listRoleNames.map( data => (
                        <option key={data.id} value={data.name}>
                        {data.name}
                    </option>
                    ))}
                </Select>     
            </Col>
            :
            <React.Fragment></React.Fragment>
        );

        return(
            <MuiContainer maxWidth="sm">
                    <div>
                        <p>{this.props.modalHeading}</p>
                    </div>
                        <Form>
                            <Container>
                                <Row className="justify-content-md-center">
                                    <Col xs lg="8">
                                        <Form.Group controlId="formBasic.ControlSelect1">
                                            <Form.Label>Project Name</Form.Label>
                                            <Form.Control 
                                                type="text" 
                                                placeholder="Project Name"
                                                name='projectName' 
                                                onChange = {this.handleChange} 
                                                noValidate 
                                                value = {this.state.projectDetails ? this.state.projectDetails.name : this.state.projectName}
                                            />
                                        </Form.Group>
                                    </Col>
                                    {addRole}
                                </Row>
                            </Container>
                            <div className="Add-Button">
                                <Button variant="primary" style = {{margin : '5px'}} onClick = {this.handleSubmit} type="submit">Submit</Button>
                            </div> 
                        </Form>
                   
                </MuiContainer>
        )
    }
}

export default AddProject;