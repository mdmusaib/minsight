import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import ToolbarNav from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import './Toolbar.css'
import { withRouter } from 'react-router-dom';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import AccountBoxOutlinedIcon from '@material-ui/icons/AccountBoxOutlined';
import Modal from './../../../components/UiElements/Modal/Modal'
import UserProfile from './../../PMSBuilder/User/UserProfile/UserProfile'

class Toolbar extends React.Component {

    constructor(props) {
        super(props);
        this.state = this.getInitialState();
    }

    getInitialState = (props) => {
        const initialState = {
            
                username: '',
                role: '',
                project: '',
                email: '',
                openForProfile: false

        }
        return initialState;
    }

    logoutClicked = (event) => {
        event.preventDefault();
        sessionStorage.removeItem('access_token');
        this.props.history.push('/login');
    }

    userIconClicked = () => {
        this.setState({
            ...this.state,
            openForProfile: true
        })
    }

    handleClose = () => {
        this.setState({
            ...this.state,
            openForProfile: false
        })
    }

    render() {

        let userData = JSON.parse(sessionStorage.getItem('access_token')) ? JSON.parse(sessionStorage.getItem('access_token')) : this.props.history.push('/login');
        let data = userData ? userData.userDetails : null
      
        return(
            <React.Fragment>
                <AppBar position="static" style ={{ backgroundColor: '#0e56e6' }} >
                    <ToolbarNav>
                        <Typography variant="h6" style = {{ color: 'white' }} >
                            {data ? data.email : this.props.history.push('/login')}
                        </Typography>
                        {
                            data.username !== 'admin'
                            ?
                            <AccountBoxOutlinedIcon fontSize = 'large' style = {{ position: 'absolute', right: '10%' }} titleAccess = "User Profile" onClick = {this.userIconClicked} />
                            :
                            <React.Fragment></React.Fragment>
                        }
                        {/* <AccountBoxOutlinedIcon fontSize = 'large' style = {{ position: 'absolute', right: '10%' }} titleAccess = "User Profile" onClick = {this.userIconClicked} />                     */}
                        <ExitToAppIcon fontSize = 'large' style = {{ position: 'absolute', right: '5%' }} onClick = {this.logoutClicked} titleAccess = "Logout"  />
                    </ToolbarNav>
                </AppBar>
                <Modal 
                    open = {this.state.openForProfile}
                    handleClose = {this.handleClose}
                >
                    <UserProfile />   
                </Modal>
            </React.Fragment>
            
        );
    }
}

export default withRouter(Toolbar);